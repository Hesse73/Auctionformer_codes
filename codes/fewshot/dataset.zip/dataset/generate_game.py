import numpy as np
from scipy.stats import norm
from tqdm import tqdm
import json


def generate_discrete_gaussian(a, b):
    probs = []
    mean, size = (a + b) / 2, b - a
    transform = lambda x: 6 / size * (x - mean)
    for v in range(a, b + 1):
        if v == a:
            probs.append(norm.cdf(transform(v + 0.5)))
        elif v == b:
            probs.append(1 - norm.cdf(transform(v - 0.5)))
        else:
            probs.append(norm.cdf(transform(v + 0.5)) - norm.cdf(transform(v - 0.5)))
    return probs


def pad_hist(hist, a, b, max_value):
    return [.0] * a + hist + [.0] * (max_value - b)


if __name__ == '__main__':
    max_player = 10
    lower_value, upper_value = 0, 20
    val_range = upper_value - lower_value + 1
    dataset_num = 10000
    start_from_zero = True

    np.random.seed(42)

    dataset = {
        'number': [],
        'uniform_value_hist': [],
        'gaussian_value_hist': [],
    }

    for game_idx in tqdm(range(dataset_num)):
        cur_player_num = np.random.randint(2, max_player + 1)

        cur_value_hist_range = []
        cur_uniform_value_hist = []
        cur_gaussian_value_hist = []

        for _ in range(cur_player_num):
            # generate game profile
            if start_from_zero:
                player_value = np.random.randint(1, upper_value + 1)
                player_value_range = [0, player_value]
                uniform_value_hist = pad_hist([1 / (player_value + 1)] * (player_value + 1), 0, player_value,
                                              upper_value)
                gaussian_value_hist = pad_hist(generate_discrete_gaussian(0, player_value), 0, player_value,
                                               upper_value)
            else:
                player_val_size = np.random.randint(1, val_range)  # [1,20]
                player_lower_value = np.random.randint(0, upper_value - player_val_size + 1)  # [0,V_max-range]
                player_upper_value = player_lower_value + player_val_size
                player_value_range = [player_lower_value, player_upper_value]  # [a,b]
                # TODO: repetition check

                # uniform value hist
                uniform_value_hist = pad_hist([1 / (player_val_size + 1)] * (player_val_size + 1), player_lower_value,
                                              player_upper_value, upper_value)
                # gaussian value hist
                gaussian_value_hist = pad_hist(generate_discrete_gaussian(*player_value_range),
                                               player_lower_value, player_upper_value, upper_value)

            cur_uniform_value_hist.append(uniform_value_hist)
            cur_gaussian_value_hist.append(gaussian_value_hist)
            cur_value_hist_range.append(player_value_range)

        dataset['number'].append(cur_player_num)
        dataset['uniform_value_hist'].append(cur_uniform_value_hist)
        dataset['gaussian_value_hist'].append(cur_gaussian_value_hist)

    postfix = 'zero' if start_from_zero else 'nonzero'
    json.dump(dataset, open('N={}_V={}_{}_{}games.json'.format(max_player,upper_value,postfix,dataset_num), 'w'))
